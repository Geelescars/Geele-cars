
document.getElementById('carForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const carName = e.target.carName.value;
    const price = e.target.price.value;
    const country = e.target.country.value;
    const region = e.target.region.value;

    const carList = document.getElementById('carList');
    const entry = document.createElement('div');
    entry.innerHTML = `<strong>${carName}</strong> - ${price} USD - ${country}, ${region}`;
    carList.appendChild(entry);

    e.target.reset();
});
